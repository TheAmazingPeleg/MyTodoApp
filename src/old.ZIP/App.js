import './App.css'
import React from "react";
import TodoList from "./TodoList";

const App = () => {
  return <TodoList />
}

export default App